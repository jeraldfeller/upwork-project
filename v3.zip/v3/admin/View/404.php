<!DOCTYPE html>
<html>
<head>
    <title>404</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h2>404 not found</h2>
    <!-- Admin content here -->
</div>

</body>
</html>
